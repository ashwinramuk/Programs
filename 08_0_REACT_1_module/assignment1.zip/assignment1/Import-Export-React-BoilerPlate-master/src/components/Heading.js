import React from 'react'

function Heading() {
    return (
        <h1>Welcome to our Site.</h1>
    )
}
export default Heading