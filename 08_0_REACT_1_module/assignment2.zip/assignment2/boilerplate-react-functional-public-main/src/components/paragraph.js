import React from "react";

const Paragraph = () => {
    return (
        <p>I am learning React. My life is getting better.</p>
    )
}

export default Paragraph