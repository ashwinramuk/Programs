import React, {Component, useState} from "react";
import Paragraph from "./paragraph"
import '../styles/App.css';

const App = () => {
  return (
    <div id="main">
      <Paragraph/>
    </div>
  )
}


export default App;
