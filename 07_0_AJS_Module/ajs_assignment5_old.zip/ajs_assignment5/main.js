const disp = document.querySelector("#input")
const numArr = document.querySelectorAll(".grid-btn-num")
const clear = document.querySelector("#clr")
const clearEntry = document.querySelector("#clr-entry")
const backspace = document.querySelector("#backspace")
const add = document.querySelector("#plus")
const sub = document.querySelector("#minus")
const mult = document.querySelector("#multiply")
const div = document.querySelector("#divide")
const ans = document.querySelector("#ans")
const dot = document.querySelector("#dot")
const negation = document.querySelector("#negative")
let number1,number2;
let flag = false;
let operator,temp;

function display(){
    if(flag) {disp.value = 0;}
    if(disp.value.length===1&&disp.value==0) disp.value = event.target.value;
    else disp.value += event.target.value//.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');//.toLocaleString('en-IN')
}
clear.addEventListener("click",function(){disp.value = 0;number1=undefined})
clearEntry.addEventListener("click",function(){disp.value = 0;number1=0})
backspace.addEventListener("click",function(){let arr = disp.value.split("");arr.pop();disp.value = parseFloat(arr.join(""))})
dot.addEventListener("click",function(){disp.value += "."})
negation.addEventListener("click",function(){disp.value = parseFloat(disp.value)*-1;})
ans.addEventListener("click",function(){
    if(flag) {number2 = parseFloat(disp.value);flag=false;}
    if(operator=="+") {number1 += number2;disp.value=number1;number1=undefined}
    else if(operator=="-") {number1 -= number2;disp.value=number1;number1=undefined}
    else if(operator=="*") {number1 *= number2;disp.value=number1;number1=undefined}
    else if(operator=="/") {number1 /= number2;disp.value=number1;number1=undefined}
    //else number1 = parseFloat(disp.value)
})
add.addEventListener("click",function(){
    if(number1!==undefined) {number1 += parseFloat(disp.value); disp.value=number1;number1=undefined}
    else number1 = parseFloat(disp.value)
    flag = true;
    operator = "+"
})
sub.addEventListener("click",function(){
    if(number1!==undefined) {number1 -= parseFloat(disp.value); disp.value=number1;number1=undefined}
    else number1 = parseFloat(disp.value)
    flag = true
    operator = "-"
})
mult.addEventListener("click",function(){
    if(number1!==undefined) {number1 *= parseFloat(disp.value); disp.value=number1;number1=undefined}
    else number1 = parseFloat(disp.value)
    flag = true
    operator = "*"
})
div.addEventListener("click",function(){
    if(number1!==undefined) {number1 /= parseFloat(disp.value); disp.value=number1;number1=undefined}
    else number1 = parseFloat(disp.value)
    flag = true
    operator = "/"
})


//function calculate(){
    // switch(event.target.value){
        // case "+":
        //     if(number1!==undefined) {number1 += parseFloat(disp.value); disp.value=number1;number1=undefined}
        //     else number1 = parseFloat(disp.value)
        //     flag = true
        // case "-":
        //     if(number1!==undefined) {number1 -= parseFloat(disp.value); disp.value=number1;number1=undefined}
        //     else number1 = parseFloat(disp.value)
        //     flag = true
        // case "*":
        //     if(number1!==undefined) {number1 *= parseFloat(disp.value); disp.value=number1;number1=undefined}
        //     else number1 = parseFloat(disp.value)
        //     flag = true
        // case "/":
        //     if(number1!==undefined) {number1 /= parseFloat(disp.value); disp.value=number1;number1=undefined}
        //     else number1 = parseFloat(disp.value)
        //     flag = true
        // default:
        //     if(number1!==undefined) {number1 = parseFloat(disp.value); disp.value=number1;number1=undefined}
        //     else number1 = parseFloat(disp.value)
        //     flag = true

//     }
// }
