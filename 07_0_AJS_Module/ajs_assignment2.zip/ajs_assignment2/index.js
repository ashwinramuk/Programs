// Unique Elements from array
// Snippet for getting input
let fs = require("fs");
let data = fs.readFileSync(0, 'utf-8');
let idx = 0;
data = data.split('\n');

function readLine() {
    idx++;
    return data[idx - 1].trim();
}
// main code
function removeDuplicates(intArr){
    return [...new Set(intArr)]
}
let no_of_testCases = parseInt(readLine())
while(no_of_testCases--){
    let arr = readLine().split(" ").map(Number)
    console.log(...removeDuplicates(arr))
}