const maxSum = document.querySelector("#max-sum")
const totalSum = document.querySelector("#sum")
const rangeA = document.querySelector("#range-a-holder")
const rangeAVal = document.querySelector("#range-a-value")
const rangeB = document.querySelector("#range-b-holder")
const rangeBVal = document.querySelector("#range-b-value")
const rangeASlide = document.querySelector("#range-a-slider")
const rangeBSlide = document.querySelector("#range-b-slider")
debugger
rangeASlide.addEventListener("change",(event) =>{
    rangeAVal.innerText = parseInt(event.target.value)
    totalSum.innerText = parseInt(rangeASlide.value)+parseInt(rangeBSlide.value)
})
rangeBSlide.addEventListener("click",(event) =>{
    rangeASlide.setAttribute("max",parseInt(maxSum.value)-parseInt(event.target.value))
    rangeBVal.innerText = parseInt(event.target.value)
    totalSum.innerText = parseInt(rangeASlide.value)+parseInt(rangeBSlide.value)
})

